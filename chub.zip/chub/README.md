# conceptshub_ideafactory_website

Static Site: https://daggieblanqx.github.io/conceptshub_ideafactory_website/index.html

desktop max 1024px
tablet max 992px
mobile max 768px


# Configuration for SCSS Live Compiler:
```{
    "workbench.sideBar.location": "right",
    "liveServer.settings.donotShowInfoMsg": true,
    "git.enableSmartCommit": true,
    "terminal.integrated.tabs.enabled": true,
    "liveServer.settings.donotVerifyTags": true,
    "git.autofetch": true,
    "liveSassCompile.settings.formats": [
        {
            "format": "compressed",
            "extensionName": ".min.css",
            "savePath": "./assets/styles/dist/"
        },
        {
            "format": "expanded",
            "extensionName": ".css",
            "savePath": "./assets/styles/dist/"
        }
    ]
}```


------------------


``json

{
    "workbench.sideBar.location": "right",
    "liveServer.settings.donotShowInfoMsg": true,
    "git.enableSmartCommit": true,
    "terminal.integrated.tabs.enabled": true,
    "liveServer.settings.donotVerifyTags": true,
    "git.autofetch": true,
    "liveSassCompile.settings.formats": [
        {
            "format": "compressed",
            "extensionName": ".min.css",
            "savePath": "./assets/styles/dist/"
        },
        {
            "format": "expanded",
            "extensionName": ".css",
            "savePath": "./assets/styles/dist/"
        }
    ],
    "liveServer.settings.CustomBrowser": "firefox",
    "window.zoomLevel": 1,
    "liveSassCompile.settings.autoprefix": []
}
``